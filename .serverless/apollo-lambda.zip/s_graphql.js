var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ralexand56',
applicationName: 'myapp',
appUid: 'LpYtYyjsdXxj1mcxbg',
tenantUid: 'Z21ts3TjdLXfbYk9kc',
deploymentUid: '4edfc6bb-da10-4c40-95b5-4a22f3d75f81',
serviceName: 'apollo-lambda',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6}
try {
  const userHandler = require('./graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
